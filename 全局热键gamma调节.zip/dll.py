from ctypes import *

USER32 = windll.user32
GDI32 = windll.gdi32